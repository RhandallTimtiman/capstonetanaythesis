<div class="container-body">
	<div class="container-fluid history">
			<div class="row section-title">
				<h1><i class="fas fa-university"></i>History</h1>
				<div class="divider">
					<hr />
				</div>
				<div class="divider2">
					<hr />
				</div>
			</div>
	</div>

	<div class="container-fluid history-updates">
		<div class="history-list-items">
		<div class="row history-row">
			<div class="col-xs-12 col-sm-6 history-item">
				<div class="history-container">
					<div class="history-title">WHAT IS LOREM IPSUM</div>
					<div class="row">
						<span class="col-sm-6 author-name">
							<i class="fas fa-user-circle"></i> Administrator
						</span>
					</div>
					<div class="history-image">
						<img id="picture">
					</div>
					<div class="history-content">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
						<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 history-item">
				<div class="history-container">
					<div class="history-title">WHAT IS LOREM IPSUM</div>
					<div class="row">
						<span class="col-sm-6 author-name">
							<i class="fas fa-user-circle"></i> Administrator
						</span>
					</div>
					<div class="history-image">
						<img id="picture">
					</div>
					<div class="history-content">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
						<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
					</div>
				</div>
			</div>
		</div>
		<div class="row divider4 hidden-xs">
			<div class="col-sm-6">
				<hr />
			</div>
			<div class="col-sm-6">
				<hr />
			</div>
		</div>
		<div class="row history-row">
			<div class="col-xs-12 col-sm-6 history-item">
				<div class="history-container">
					<div class="history-title">WHAT IS LOREM IPSUM</div>
					<div class="row">
						<span class="col-sm-6 author-name">
							<i class="fas fa-user-circle"></i> Administrator
						</span>
					</div>
					<div class="history-image">
						<img id="picture">
					</div>
					<div class="history-content">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequatbryan is sow pogi i dont know why...
						<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 history-item">
				<div class="history-container">
					<div class="history-title">WHAT IS LOREM IPSUM</div>
					<div class="row">
						<span class="col-sm-6 author-name">
							<i class="fas fa-user-circle"></i> Administrator
						</span>
					</div>
					<div class="history-image">
						<img id="picture">
					</div>
					<div class="history-content">
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequatbryan is sow pogi i dont know why...
						<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div style="text-align:center;">
	  <div class="news-button">
	    <button class="all-news" id="buttonallhistory" role="button"> View All History </button>
	  </div>
	</div>

		<div class="container-fluid culture-arts">
			<div class="row section-title">
				<h1>CULTURE & ARTS</h1>
			</div>
		</div>

	<div class="container-fluid culture-arts-updates">
		<div class="culture-arts-list">
			<div class="row history-row">
				<div class="col-xs-12 col-sm-6 history-item">
					<div class="history-container">
						<div class="history-title">WHAT IS LOREM IPSUM</div>
						<div class="row">
							<span class="col-sm-6 author-name">
								<i class="fas fa-user-circle"></i> Administrator
							</span>
						</div>
						<div class="history-image">
							<img id="picture">
						</div>
						<div class="history-content">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
							<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 history-item">
					<div class="history-container">
						<div class="history-title">WHAT IS LOREM IPSUM</div>
						<div class="row">
							<span class="col-sm-6 author-name">
								<i class="fas fa-user-circle"></i> Administrator
							</span>
						</div>
						<div class="history-image">
							<img id="picture">
						</div>
						<div class="history-content">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
							<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
						</div>
					</div>
				</div>
			</div>
			<div class="row divider4 hidden-xs">
				<div class="col-sm-6">
					<hr />
				</div>
				<div class="col-sm-6">
					<hr />
				</div>
			</div>
			<div class="row history-row">
				<div class="col-xs-12 col-sm-6 history-item">
					<div class="history-container">
						<div class="history-title">WHAT IS LOREM IPSUM</div>
						<div class="row">
							<span class="col-sm-6 author-name">
								<i class="fas fa-user-circle"></i> Administrator
							</span>
						</div>
						<div class="history-image">
							<img id="picture">
						</div>
						<div class="history-content">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequatbryan is sow pogi i dont know why...
							<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 history-item">
					<div class="history-container">
						<div class="history-title">WHAT IS LOREM IPSUM</div>
						<div class="row">
							<span class="col-sm-6 author-name">
								<i class="fas fa-user-circle"></i> Administrator
							</span>
						</div>
						<div class="history-image">
							<img id="picture">
						</div>
						<div class="history-content">
							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequatbryan is sow pogi i dont know why...
							<a href="history/what-is-lorem-ipsum" class="read-more" role="button">read more</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6">
				<div style="text-align:center;">
					<div class="news-button">
						<button class="all-news" id="buttonallculture" role="button"> View All Culture </button>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div style="text-align:center;">
					<div class="news-button">
						<button class="all-news" id="buttonallarts" role="button"> View All Arts </button>
					</div>
				</div>
			</div>
		</div>
	</div>
