<div class="container-fluid news-and-update">
  <div class="row section-title">
    <h1><i class="fas fa-newspaper"></i>NEWS</h1>

    <h2>What's New?!</h2>

    <div class="divider">
      <hr />
    </div>

    <div class="latest-update">
      <h3 id="Update">Last Update August 23,2018 3:00PM</h3>
    </div>

    <div class="divider2">
      <hr />
    </div>
  </div>
  <div class="news_list">
    <div class="row news-row">
      <div class="col-xs-12 col-sm-6 news-item">
        <div class="news-container">
          <div class="news-title">
            WHAT IS LOREM IPSUM
          </div>

          <div class="row">
            <span class="col-sm-6 author-name">
              <i class="fas fa-user-circle"></i> Administrator
            </span>
            <span class="col-sm-6 date-posted">
              <i class="far fa-calendar-times"></i> August 9, 2018
            </span>
          </div>

          <div class="news-image">
              <img id="news-picture">
          </div>

          <div class="news-content">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
            veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
            commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
            elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
            <a href="news/details/news-and-update/what-is-lorem-ipsum" class="read-more" role="button">read
            more</a>
          </div>
        </div>
      </div>

      <div class="col-xs-12 col-sm-6 news-item">
        <div class="news-container">
          <div class="news-title">
            WHAT IS LOREM IPSUM
          </div>

          <div class="row">
            <span class="col-sm-6 author-name">
              <i class="fas fa-user-circle"></i> Administrator
            </span>
            <span class="col-sm-6 date-posted">
              <i class="far fa-calendar-times"></i> August 9, 2018
            </span>
          </div>

          <div class="news-content">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
            veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
            commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
            elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
            <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
            more</a>
          </div>
        </div>
      </div>

    </div>

    <div class="row divider3 hidden-xs">
      <div class="col-sm-6">
        <hr />
      </div>

      <div class="col-sm-6">
        <hr />
      </div>
    </div>

    <div class="row news-row">
      <div class="col-xs-12 col-sm-6 news-item">
        <div class="news-container">
          <div class="news-title">
            WHAT IS LOREM IPSUM
          </div>

          <div class="row">
            <span class="col-sm-6 author-name">
              <i class="fas fa-user-circle"></i> Administrator
            </span>
            <span class="col-sm-6 date-posted">
              <i class="far fa-calendar-times"></i> August 9, 2018
            </span>
          </div>

          <div class="news-content">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
            veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
            commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
            elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
            <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
            more</a>
          </div>
        </div>
      </div>

      <div class="col-xs-12 col-sm-6 news-item">
        <div class="news-container">
          <div class="news-title">
            WHAT IS LOREM IPSUM
          </div>

         <div class="row">
            <span class="col-sm-6 author-name">
              <i class="fas fa-user-circle"></i> Administrator
            </span>
            <span class="col-sm-6 date-posted">
              <i class="far fa-calendar-times"></i> August 9, 2018
            </span>
          </div>

          <div class="news-content">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
            veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
            commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
            elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
            ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
            <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
            more</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div style="text-align:center;">
    <div class="news-button">
      <button class="all-news" id="buttonallnews" role="button">View All news </button>
    </div>
  </div>
</div>

<div class="container-fluid announcement">
  <div class="row section-title">
    <h1><i class="fas fa-bullhorn"></i>Announcement</h1>
    <div class="divider">
      <hr />
    </div>
    <div class="divider2">
      <hr />
    </div>
  </div>
<div class="announcement-list">
  <div class="row news-row">
    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

        <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-image">
            <img id="news-picture">
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>

    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

        <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>

  </div>

  <div class="row divider3 hidden-xs">
    <div class="col-sm-6">
      <hr />
    </div>

    <div class="col-sm-6">
      <hr />
    </div>
  </div>

  <div class="row news-row">
    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

        <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>

    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

       <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div style="text-align:center;">
  <div class="news-button">
    <button class="all-news" id="buttonallannouncements" role="button"> View All Announcements </button>
  </div>
</div>
</div>

<div class="container-fluid special-feature">
  <div class="row section-title">
    <h1><i class="fas fa-camera"></i>Special Features</h1>
    <div class="divider">
      <hr />
    </div>
    <div class="divider2">
      <hr />
    </div>
  </div>
<div class="special-list">
  <div class="row news-row">
    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

        <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-image">
            <img id="news-picture">
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>

    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

        <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>

  </div>

  <div class="row divider3 hidden-xs">
    <div class="col-sm-6">
      <hr />
    </div>

    <div class="col-sm-6">
      <hr />
    </div>
  </div>

  <div class="row news-row">
    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

        <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>

    <div class="col-xs-12 col-sm-6 news-item">
      <div class="news-container">
        <div class="news-title">
          WHAT IS LOREM IPSUM
        </div>

       <div class="row">
          <span class="col-sm-6 author-name">
            <i class="fas fa-user-circle"></i> Administrator
          </span>
          <span class="col-sm-6 date-posted">
            <i class="far fa-calendar-times"></i> August 9, 2018
          </span>
        </div>

        <div class="news-content">
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
          veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
          commodo consequat. Lorem ipsum dolor sit amet, consectetur adipisicing
          elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
          ut aliquip ex ea commodo consequat bryan is sow pogi i dont know why...
          <a href="news/what-is-lorem-ipsum" class="read-more" role="button">read
          more</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div style="text-align:center;">
  <div class="news-button">
    <button class="all-news" id="buttonallspecialfeatures" role="button"> View All Special Features </button>
  </div>
</div>
</div>
