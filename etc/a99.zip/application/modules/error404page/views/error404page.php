<div class="error404page">
	<div class="row">
		<h1>
			<img src="<?php echo base_url('assets/images/error404page-icon.png'); ?>" />
			<span>Oops! The page you are looking for is unavailable.</span>
		</h1>
		<h3>
			<a href="javascript: window.history.back();" class="btn btn-lg btn-warning" id="btnBack">
				Back to Previous Page
			</a>
		</h3>
	</div>
</div>
